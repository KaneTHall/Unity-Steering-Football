﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class RandomMovement : MonoBehaviour {

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
      /* Vector2 P = this.transform.position;
       Vector2 V = new Vector2(Random.Range(0,0.1f), Random.Range(0, 0.1f));
        P += V;
        this.transform.position = P;
        */
    }
}
